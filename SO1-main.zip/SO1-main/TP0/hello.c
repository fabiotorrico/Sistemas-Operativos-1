/*
Ejercicio 0:
Escriba un programa hello world. Compilar y ejecutar.
   Por ejemplo: 
		vi hello.c   # edicion. Usar vi u otro editro de predileccion
		make hello   # compilacion
		gcc -o hello hello.c # compilación invocando gcc)
		./hello	     # ejecucion
*/
main(){
    printf("Hello world!\n");
}