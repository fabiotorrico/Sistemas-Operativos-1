#include <xinu.h>

void	mi_programa(void)
{
	printf("Hola mundo! \n");	
}
